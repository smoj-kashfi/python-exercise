def code_melli_checker(code):

    code = str(code).strip()
    # 1- only digits
    if not code.isdigit():
        return False
    # 2- Reject if length is less than 8 or the numeric value is zero
    if len(code) < 8 or int(code) == 0:
        return False
    # 3- Left-pad with zeros to ensure a length of 10
    code = code.zfill(10)
    # 4- The middle six digits (positions 4–9) must not all be zero
    if int(code[3:9]) == 0:
        return False
    # 5- Extract the check digit (the last digit)
    check_digit = int(code[9])
    # 6- weights decrease from 10 down to 2
    total = sum(int(code[i]) * (10 - i) for i in range(9))
    # 7- Compute remainder of division by 11
    remainder = total % 11
    # If remainder is less than 2, it must match the check digit;
    # otherwise the check digit must equal (11 - remainder)
    if remainder < 2:
        return check_digit == remainder
    else:
        return check_digit == 11 - remainder


code = input("Enter a ID code: ")
if code_melli_checker(code):
    print("VALID")
else:
    print("NOT VALID")