def fibonacci_series(n):
    series = []
    a, b = 0, 1
    for _ in range(n):
        series.append(a)
        a, b = b, a + b
    return series


while True:
    user_input = input("Enter number of fibonacci series: ")
    try:
        n = int(user_input)
        if n <= 0:
            print("Please enter a positive integer")
            continue
        break
    except ValueError:
        print("Please enter a valid integer")

print(", ".join(str(num) for num in fibonacci_series(n)))