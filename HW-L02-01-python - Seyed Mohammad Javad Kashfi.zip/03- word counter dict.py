import re

def count_words(text):
    # 1. Convert all characters to lowercase
    text = text.lower()
    # 2. Remove all non-letter characters (punctuation, digits, etc.)
    text = re.sub(r'[^a-z\u0600-\u06FF\s]', '', text)
    # 3. Split the text into words
    words = text.split()
    # 4. Build a dictionary counting each word’s occurrences
    counts = {}
    for w in words:
        counts[w] = counts.get(w, 0) + 1
    return counts


user_input = input("Please enter a sentence:\n")
result = count_words(user_input)
print(result)